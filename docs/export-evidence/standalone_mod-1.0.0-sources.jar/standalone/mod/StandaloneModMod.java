package standalone.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StandaloneModMod implements ModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("standalone_mod");

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing Standalone Mod");
		ModItems.initialize();
		ModBlocks.initialize();
	}
}
