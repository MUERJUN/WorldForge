package standalone.mod;

import net.minecraft.class_2960;
import net.minecraft.class_4516;
import net.minecraft.class_6302;
import net.minecraft.class_7923;

public class ExportedModTest {
	@class_6302(method_35936 = "fabric-gametest-api-v1:empty", method_35933 = "exported")
	public static void itemRegistered1(class_4516 ctx) {
		var item = class_7923.field_41178.method_10223(class_2960.method_60655("standalone_mod", "standalone_sword"));
		if (item == null || item == net.minecraft.class_1802.field_8162) {
			throw new AssertionError("Item standalone_sword not registered");
		}
		ctx.method_36036();
	}

	@class_6302(method_35936 = "fabric-gametest-api-v1:empty", method_35933 = "exported")
	public static void blockRegistered2(class_4516 ctx) {
		var block = class_7923.field_41175.method_10223(class_2960.method_60655("standalone_mod", "standalone_block"));
		if (block == null || block == net.minecraft.class_2246.field_10124) {
			throw new AssertionError("Block standalone_block not registered");
		}
		ctx.method_36036();
	}

}
