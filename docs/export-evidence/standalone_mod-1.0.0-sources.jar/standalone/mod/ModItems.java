package standalone.mod;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
	private ModItems() {}

	static void initialize() {
		var ITEM_STANDALONE_SWORD = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655("standalone_mod", "standalone_sword"),
				new class_1792(new class_1792.class_1793()));
	}
}
