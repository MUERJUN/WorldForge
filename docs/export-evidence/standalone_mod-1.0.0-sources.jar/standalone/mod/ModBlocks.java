package standalone.mod;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModBlocks {
	private ModBlocks() {}

	static void initialize() {
		var BLOCK_STANDALONE_BLOCK = class_2378.method_10230(class_7923.field_41175,
				class_2960.method_60655("standalone_mod", "standalone_block"),
				new class_2248(class_2248.Settings.method_9637().method_9632(2.0f)));
		class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655("standalone_mod", "standalone_block"),
				new class_1747(BLOCK_STANDALONE_BLOCK, new class_1792.class_1793()));
	}
}
